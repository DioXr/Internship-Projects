﻿function openAdd(section) {
    const container = document.getElementById(section + "-form");
    fetch(`/Admin/${capitalize(section)}/CreatePartial?cvId=${window.cvId}`)
        .then(r => r.text())
        .then(html => {
            container.innerHTML = html;
            container.classList.remove("hidden");
        });
}

function openEdit(section, id) {
    const container = document.getElementById(section + "-form");
    fetch(`/Admin/${capitalize(section)}/EditPartial?id=${id}`)
        .then(r => r.text())
        .then(html => {
            container.innerHTML = html;
            container.classList.remove("hidden");
        });
}

function capitalize(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
}
