﻿function getController(section) {
    switch (section) {
        case 'personal':
            return 'PersonalDetails';
        case 'education':
            return 'Education';
        case 'skills':
            return 'Skills';
        default:
            return section.charAt(0).toUpperCase() + section.slice(1);
    }
}

function toggleSection(section) {
    const content = document.getElementById(section + '-content');
    const form = document.getElementById(section + '-form');

    if (!content || !form) {
        console.error('Missing DOM elements for section:', section);
        return;
    }

    content.classList.add('hidden');
    form.classList.remove('hidden');
}

function closeInlineForm(section) {
    const content = document.getElementById(section + '-content');
    const form = document.getElementById(section + '-form');

    if (!content || !form) return;

    form.innerHTML = '';
    form.classList.add('hidden');
    content.classList.remove('hidden');
}

function loadPartial(section, action) {
    const controller = getController(section);
    const url = `/${controller}/${action}`;

    fetch(url)
        .then(res => {
            if (!res.ok) throw new Error('Failed to load partial');
            return res.text();
        })
        .then(html => {
            document.getElementById(section + '-form').innerHTML = html;
        })
        .catch(err => console.error(err));
}

function openAdd(section) {
    toggleSection(section);
    loadPartial(section, 'CreatePartial');
}

function openEdit(section, id) {
    toggleSection(section);

    if (section === 'personal') {
        loadPartial(section, 'EditPartial');
    } else {
        loadPartial(section, `EditPartial?id=${id}`);
    }
}

function submitInlineForm(e) {
    e.preventDefault();
    const form = e.target;

    fetch(form.action, {
        method: 'POST',
        body: new FormData(form)
    }).then(() => window.location.reload());
}
