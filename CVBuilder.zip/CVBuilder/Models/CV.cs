﻿using CVBuilder.Models;

public class CV
{
    public int Id { get; set; }

    public string UserId { get; set; }

    public ApplicationUser User { get; set; }

    public ICollection<Experience> Experiences { get; set; } = new List<Experience>();
    public ICollection<Project> Projects { get; set; } = new List<Project>();
    public ICollection<Education> Educations { get; set; } = new List<Education>();
    public ICollection<Skill> Skills { get; set; } = new List<Skill>();

    public PersonalDetails PersonalDetails { get; set; }
}
