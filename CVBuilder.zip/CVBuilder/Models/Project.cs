﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace CVBuilder.Models
{
    public class Project
    {
        public int Id { get; set; }

        public int CVId { get; set; }

        [ValidateNever]
        public CV CV { get; set; }

        [Required]
        public string Title { get; set; }

        public string? TechStack { get; set; }

        public string? Description { get; set; }

        public string? ProjectLink { get; set; }
    }
}
