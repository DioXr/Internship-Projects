﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace CVBuilder.Models
{
    public class Experience
    {
        public int Id { get; set; }

        public int CVId { get; set; }

        [ValidateNever]
        public CV CV { get; set; }

        [Required]
        public string Role { get; set; }

        [Required]
        public string Company { get; set; }

        [ValidateNever]
        public string? StartYear { get; set; }

        [ValidateNever]
        public string? EndYear { get; set; }

        [ValidateNever]
        public string? Description { get; set; }
    }
}
