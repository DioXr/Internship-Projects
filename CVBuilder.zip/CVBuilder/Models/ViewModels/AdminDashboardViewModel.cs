﻿namespace CVBuilder.Models.ViewModels
{
    public class AdminDashboardViewModel
    {
        public int TotalUsers { get; set; }
        public int TotalCVs { get; set; }
        public int TotalEducations { get; set; }
        public int TotalSkills { get; set; }
    }
}
