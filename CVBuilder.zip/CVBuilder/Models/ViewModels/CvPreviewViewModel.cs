﻿using System.Collections.Generic;

namespace CVBuilder.Models.ViewModels
{
    public class CvPreviewViewModel
    {
        public int CVId { get; set; }
        public PersonalDetails? PersonalDetails { get; set; }
        public List<Education> Educations { get; set; } = new();
        public List<Skill> Skills { get; set; } = new();

        public List<Experience> Experiences { get; set; } = new();
        public List<Project> Projects { get; set; } = new();

        public bool CanEdit { get; set; } public bool CanDelete { get; set; }

        }
}
