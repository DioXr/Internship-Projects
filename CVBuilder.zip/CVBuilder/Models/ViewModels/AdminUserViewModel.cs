﻿namespace CVBuilder.Models.ViewModels
{
    public class AdminUserViewModel
    {
        public string UserId { get; set; }
        public string Email { get; set; }
        public bool HasCV { get; set; }
        public int CVId { get; set; }
    }
}