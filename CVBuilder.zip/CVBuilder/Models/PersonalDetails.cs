﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace CVBuilder.Models
{
    public class PersonalDetails
    {
        public int Id { get; set; }

        public int CVId { get; set; }

        [ValidateNever]
        public CV CV { get; set; }

        [Required]
        public string FullName { get; set; }

        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }

        // 👇 NEW FIELD
        public string? ProfileSummary { get; set; }
    }
}
