﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace CVBuilder.Models
{
    public class Education
    {
        public int Id { get; set; }

        public int CVId { get; set; }

        [ValidateNever]
        public CV CV { get; set; }

        [Required]
        public string Degree { get; set; }

        [Required]
        public string Institute { get; set; }

        // Display data → do NOT let MVC bind
        [ValidateNever]
        public string? StartYear { get; set; }

        [ValidateNever]
        public string? EndYear { get; set; }
    }
}
