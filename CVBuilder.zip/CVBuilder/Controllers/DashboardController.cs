﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace CVBuilder.Controllers
{
    [Authorize]
    public class DashboardController : CvBaseController
    {
        public DashboardController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        ) : base(context, userManager)
        {
        }

        // Dashboard is now just an entry point
        // Always redirect to CV Preview
        public IActionResult Index()
        {
            return RedirectToAction("Preview", "CV");
        }
    }
}
