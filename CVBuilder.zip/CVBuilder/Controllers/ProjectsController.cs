﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace CVBuilder.Controllers
{
    [Authorize]
    public class ProjectsController : CvBaseController
    {
        public ProjectsController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        ) : base(context, userManager) { }

        // CREATE (INLINE)
        public IActionResult CreatePartial()
        {
            return PartialView("Partials/_ProjectForm", new Project());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Project model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            if (!ModelState.IsValid)
                return RedirectToAction("Preview", "CV");

            model.CVId = cv.Id;

            _context.Projects.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }

        // EDIT (INLINE)
        public IActionResult EditPartial(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var project = _context.Projects
                .FirstOrDefault(p => p.Id == id && p.CVId == cv.Id);

            if (project == null)
                return NotFound();

            return PartialView("Partials/_ProjectForm", project);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Project model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var existing = _context.Projects
                .FirstOrDefault(p => p.Id == model.Id && p.CVId == cv.Id);

            if (existing == null)
                return NotFound();

            existing.Title = model.Title;
            existing.TechStack = model.TechStack;
            existing.Description = model.Description;
            existing.ProjectLink = model.ProjectLink;

            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }

        public IActionResult Delete(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var project = _context.Projects
                .FirstOrDefault(p => p.Id == id && p.CVId == cv.Id);

            if (project == null)
                return NotFound();

            _context.Projects.Remove(project);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }
    }
}
