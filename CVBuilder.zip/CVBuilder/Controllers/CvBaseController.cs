﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace CVBuilder.Controllers
{
    public abstract class CvBaseController : Controller
    {
        protected readonly ApplicationDbContext _context;
        protected readonly UserManager<ApplicationUser> _userManager;

        protected CvBaseController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (User.Identity?.IsAuthenticated == true)
            {
                var userId = _userManager.GetUserId(User);

                var cv = _context.CVs.FirstOrDefault(c => c.UserId == userId);
                if (cv == null)
                {
                    _context.CVs.Add(new CV
                    {
                        UserId = userId
                    });
                    _context.SaveChanges();
                }
            }

            base.OnActionExecuting(context);
        }
    }
}
