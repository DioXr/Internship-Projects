﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

[Authorize(Roles = "Admin")]
public class AdminPersonalDetailsController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminPersonalDetailsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // ---------- GET EDIT ----------
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var details = _context.PersonalDetails.Find(id);
        if (details == null) return NotFound();

        return View(
            "~/Views/Admin/AdminPersonalDetails/Edit.cshtml",
            details
        );
    }

    // ---------- POST EDIT ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(PersonalDetails model)
    {
        if (!ModelState.IsValid)
        {
            return View(
                "~/Views/Admin/AdminPersonalDetails/Edit.cshtml",
                model
            );
        }

        var existing = _context.PersonalDetails.Find(model.Id);
        if (existing == null) return NotFound();

        existing.FullName = model.FullName;
        existing.Email = model.Email;
        existing.Phone = model.Phone;
        existing.Address = model.Address;
        existing.ProfileSummary = model.ProfileSummary;

        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == existing.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }
}