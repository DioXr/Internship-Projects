﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize(Roles = "Admin")]
public class AdminProjectsController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminProjectsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // ---------- CREATE ----------
    [HttpGet]
    public IActionResult Create(int cvId)
    {
        return View(new Project { CVId = cvId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Project model)
    {
        if (!ModelState.IsValid)
            return View(model);

        _context.Projects.Add(model);
        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == model.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- EDIT ----------
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var project = _context.Projects.Find(id);
        if (project == null) return NotFound();

        return View(project);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(Project model)
    {
        if (!ModelState.IsValid)
            return View(model);

        var existing = _context.Projects.Find(model.Id);
        if (existing == null) return NotFound();

        existing.Title = model.Title;
        existing.Description = model.Description;
        existing.ProjectLink = model.ProjectLink;

        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == existing.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- DELETE ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Delete(int id)
    {
        var project = _context.Projects
            .Include(p => p.CV)
            .FirstOrDefault(p => p.Id == id);

        if (project == null) return NotFound();

        var userId = project.CV.UserId;

        _context.Projects.Remove(project);
        _context.SaveChanges();

        return RedirectToAction("View", "AdminCV", new { userId });
    }
}