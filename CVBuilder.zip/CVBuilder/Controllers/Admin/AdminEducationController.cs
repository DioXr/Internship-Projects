﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize(Roles = "Admin")]
public class AdminEducationController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminEducationController(ApplicationDbContext context)
    {
        _context = context;
    }

    // ---------- CREATE ----------
    [HttpGet]
    public IActionResult Create(int cvId)
    {
        return View(new Education { CVId = cvId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Education model)
    {
        if (!ModelState.IsValid)
            return View(model);

        _context.Educations.Add(model);
        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == model.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- EDIT ----------
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var edu = _context.Educations.Find(id);
        if (edu == null) return NotFound();

        return View(edu);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(Education model)
    {
        if (!ModelState.IsValid)
            return View(model);

        var existing = _context.Educations.Find(model.Id);
        if (existing == null) return NotFound();

        // 🔑 update fields manually
        existing.Degree = model.Degree;
        existing.Institute = model.Institute;
        existing.StartYear = model.StartYear;
        existing.EndYear = model.EndYear;

        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == existing.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- DELETE ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Delete(int id)
    {
        var edu = _context.Educations
            .Include(e => e.CV)
            .FirstOrDefault(e => e.Id == id);

        if (edu == null) return NotFound();

        var userId = edu.CV.UserId;

        _context.Educations.Remove(edu);
        _context.SaveChanges();

        return RedirectToAction("View", "AdminCV", new { userId });
    }
}