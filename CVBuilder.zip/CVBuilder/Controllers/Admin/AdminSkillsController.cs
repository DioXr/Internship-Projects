﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize(Roles = "Admin")]
public class AdminSkillsController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminSkillsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // ---------- CREATE ----------
    [HttpGet]
    public IActionResult Create(int cvId)
    {
        return View(new Skill { CVId = cvId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Skill model)
    {
        if (!ModelState.IsValid)
            return View(model);

        _context.Skills.Add(model);
        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == model.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- EDIT ----------
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var skill = _context.Skills.Find(id);
        if (skill == null) return NotFound();

        return View(skill);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(Skill model)
    {
        if (!ModelState.IsValid)
            return View(model);

        var existing = _context.Skills.Find(model.Id);
        if (existing == null) return NotFound();

        existing.SkillName = model.SkillName;

        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == existing.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- DELETE ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Delete(int id)
    {
        var skill = _context.Skills
            .Include(s => s.CV)
            .FirstOrDefault(s => s.Id == id);

        if (skill == null) return NotFound();

        var userId = skill.CV.UserId;

        _context.Skills.Remove(skill);
        _context.SaveChanges();

        return RedirectToAction("View", "AdminCV", new { userId });
    }
}