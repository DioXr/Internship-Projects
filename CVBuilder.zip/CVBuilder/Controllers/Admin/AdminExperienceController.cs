﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize(Roles = "Admin")]
public class AdminExperienceController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminExperienceController(ApplicationDbContext context)
    {
        _context = context;
    }

    // ---------- CREATE ----------
    [HttpGet]
    public IActionResult Create(int cvId)
    {
        return View(new Experience { CVId = cvId });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Create(Experience model)
    {
        if (!ModelState.IsValid)
            return View(model);

        _context.Experiences.Add(model);
        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == model.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- EDIT ----------
    [HttpGet]
    public IActionResult Edit(int id)
    {
        var exp = _context.Experiences.Find(id);
        if (exp == null) return NotFound();

        return View(exp);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(Experience model)
    {
        if (!ModelState.IsValid)
            return View(model);

        var existing = _context.Experiences.Find(model.Id);
        if (existing == null) return NotFound();

        existing.Role = model.Role;
        existing.Company = model.Company;
        existing.StartYear = model.StartYear;
        existing.EndYear = model.EndYear;
        existing.Description = model.Description;

        _context.SaveChanges();

        var userId = _context.CVs
            .Where(c => c.Id == existing.CVId)
            .Select(c => c.UserId)
            .First();

        return RedirectToAction("View", "AdminCV", new { userId });
    }

    // ---------- DELETE ----------
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Delete(int id)
    {
        var exp = _context.Experiences
            .Include(e => e.CV)
            .FirstOrDefault(e => e.Id == id);

        if (exp == null) return NotFound();

        var userId = exp.CV.UserId;

        _context.Experiences.Remove(exp);
        _context.SaveChanges();

        return RedirectToAction("View", "AdminCV", new { userId });
    }
}