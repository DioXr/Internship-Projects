﻿using CVBuilder.Data;
using CVBuilder.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CVBuilder.Controllers.Admin
{
    [Authorize(Roles = "Admin,ContentManager")]
    [Route("admin")]
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("")]
        public IActionResult Dashboard()
        {
            var vm = new AdminDashboardViewModel
            {
                TotalUsers = _context.Users.Count(),
                TotalCVs = _context.CVs.Count()
            };

            return View(vm);
        }

        [HttpGet("Users")]
        public IActionResult Users()
        {
            var users = _context.Users
                .Select(u => new AdminUserViewModel
                {
                    UserId = u.Id,
                    Email = u.Email,
                    HasCV = _context.CVs.Any(c => c.UserId == u.Id),
                    CVId = _context.CVs
                            .Where(c => c.UserId == u.Id)
                            .Select(c => c.Id)
                            .FirstOrDefault()
                })
                .ToList();

            return View(users);
        }

    }
}
