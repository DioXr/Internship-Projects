﻿using CVBuilder.Data;
using CVBuilder.Models;
using CVBuilder.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize(Roles = "Admin,ContentManager")]
[Route("admin/cv")]
public class AdminCVController : Controller
{
    private readonly ApplicationDbContext _context;

    public AdminCVController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet("")]
    [HttpGet("{userId}")]
    public IActionResult View(string userId, int? cvId)
    {
        CV cv = null;

        if (!string.IsNullOrEmpty(userId))
        {
            cv = _context.CVs
                .Include(c => c.PersonalDetails)
                .Include(c => c.Educations)
                .Include(c => c.Experiences)
                .Include(c => c.Skills)
                .Include(c => c.Projects)
                .FirstOrDefault(c => c.UserId == userId);
        }
        else if (cvId.HasValue)
        {
            cv = _context.CVs
                .Include(c => c.PersonalDetails)
                .Include(c => c.Educations)
                .Include(c => c.Experiences)
                .Include(c => c.Skills)
                .Include(c => c.Projects)
                .FirstOrDefault(c => c.Id == cvId.Value);
        }

        if (cv == null)
            return RedirectToAction("Users", "Admin");

        var vm = new CvPreviewViewModel
        {
            CVId = cv.Id,
            PersonalDetails = cv.PersonalDetails,
            Educations = cv.Educations.ToList(),
            Experiences = cv.Experiences.ToList(),
            Skills = cv.Skills.ToList(),
            Projects = cv.Projects.ToList(),

           
            CanEdit = User.IsInRole("Admin"),
            CanDelete = User.IsInRole("Admin")
        };

        return View("~/Views/Admin/AdminCV/View.cshtml", vm);
    }
}