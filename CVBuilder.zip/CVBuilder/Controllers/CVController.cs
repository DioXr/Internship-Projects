﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using CVBuilder.Models.ViewModels;


namespace CVBuilder.Controllers
{
    [Authorize]
    public class CVController : CvBaseController
    {
        public CVController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        ) : base(context, userManager)
        {
        }

        public IActionResult Preview()
        {
            var userId = _userManager.GetUserId(User);

            var cv = _context.CVs.First(c => c.UserId == userId);

            var model = new CvPreviewViewModel
            {
                PersonalDetails = _context.PersonalDetails
                    .FirstOrDefault(p => p.CVId == cv.Id),

                Educations = _context.Educations
                    .Where(e => e.CVId == cv.Id)
                    .ToList(),

                Skills = _context.Skills
                    .Where(s => s.CVId == cv.Id)
                    .ToList(),

                Experiences = _context.Experiences
        .Where(e => e.CVId == cv.Id)
        .ToList(),
            

            Projects = _context.Projects
    .Where(p => p.CVId == cv.Id)
    .ToList()

            };
            return View(model);
        }
    }
}
