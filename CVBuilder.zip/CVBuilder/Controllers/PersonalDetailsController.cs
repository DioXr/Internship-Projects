﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace CVBuilder.Controllers
{
    [Authorize]
    public class PersonalDetailsController : CvBaseController
    {
        public PersonalDetailsController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        ) : base(context, userManager)
        {
        }

        // GET: /PersonalDetails
        public IActionResult Index()
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var details = _context.PersonalDetails
                .FirstOrDefault(p => p.CVId == cv.Id);

            if (details == null)
            {
                details = new PersonalDetails
                {
                    CVId = cv.Id
                };
            }

            return View(details);
        }

        // ✅ GET: /PersonalDetails/EditPartial
        [HttpGet]
        public IActionResult EditPartial()
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var details = _context.PersonalDetails
                .FirstOrDefault(p => p.CVId == cv.Id);

            // ⚠️ DO NOT SAVE HERE
            if (details == null)
            {
                details = new PersonalDetails
                {
                    CVId = cv.Id
                };
            }

            ViewBag.FormAction = Url.Action("Save");
            return PartialView("Partials/_PersonalDetailsForm", details);
        }


        // ✅ POST: /PersonalDetails/Save
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Save(PersonalDetails model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var existing = _context.PersonalDetails
                .FirstOrDefault(p => p.CVId == cv.Id);

            if (existing == null)
            {
                model.CVId = cv.Id;
                _context.PersonalDetails.Add(model);
            }
            else
            {
                existing.FullName = model.FullName;
                existing.Email = model.Email;
                existing.Phone = model.Phone;
                existing.Address = model.Address;
                existing.ProfileSummary = model.ProfileSummary;
            }

            _context.SaveChanges();
            return RedirectToAction("Preview", "CV");
        }
    }
}
