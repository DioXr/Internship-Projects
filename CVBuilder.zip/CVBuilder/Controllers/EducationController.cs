﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace CVBuilder.Controllers
{
    [Authorize]
    public class EducationController : CvBaseController
    {
        public EducationController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        ) : base(context, userManager)
        {
        }

        // LIST
        public IActionResult Index()
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var educations = _context.Educations
                .Where(e => e.CVId == cv.Id)
                .ToList();

            return View(educations);
        }

        // CREATE (GET)
        public IActionResult Create()
        {
            return View();
        }
        public IActionResult CreatePartial()
        {
            ViewBag.FormAction = Url.Action("Create");
            return PartialView("Partials/_EducationForm", new Education());
        }

        // CREATE (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Education model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            if (!ModelState.IsValid)
                return View(model);

            model.CVId = cv.Id;
            model.StartYear = Request.Form["StartYear"];
            model.EndYear = Request.Form["EndYear"];

            _context.Educations.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }

      



        // EDIT (GET)
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var education = _context.Educations
                .FirstOrDefault(e => e.Id == id && e.CVId == cv.Id);

            if (education == null)
            {
                return NotFound();
            }

            return View(education);
        }
        
        public IActionResult EditPartial(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var education = _context.Educations
                .FirstOrDefault(e => e.Id == id && e.CVId == cv.Id);

            if (education == null)
                return NotFound();

            ViewBag.FormAction = Url.Action("Edit");
            return PartialView("Partials/_EducationForm", education);
        }


        // EDIT (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Education model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var existing = _context.Educations
                .FirstOrDefault(e => e.Id == model.Id && e.CVId == cv.Id);

            if (existing == null)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            existing.Degree = model.Degree;
            existing.Institute = model.Institute;
            existing.StartYear = Request.Form["StartYear"];
            existing.EndYear = Request.Form["EndYear"];

            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }


        // DELETE
        public IActionResult Delete(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var education = _context.Educations
                .FirstOrDefault(e => e.Id == id && e.CVId == cv.Id);

            if (education == null)
            {
                return NotFound();
            }

            _context.Educations.Remove(education);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }
    }
}
