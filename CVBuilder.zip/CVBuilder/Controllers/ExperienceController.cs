﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace CVBuilder.Controllers
{
    [Authorize]
    public class ExperienceController : CvBaseController
    {
        public ExperienceController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        ) : base(context, userManager) { }

        public IActionResult CreatePartial()
        {
            ViewBag.FormAction = Url.Action("Create");
            return PartialView("Partials/_ExperienceForm", new Experience());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Experience model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            if (!ModelState.IsValid)
            {
                return RedirectToAction("Preview", "CV");
            }

            model.CVId = cv.Id;

            _context.Experiences.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }

        public IActionResult EditPartial(int id)
        {
            var cv = _context.CVs.First(c => c.UserId == _userManager.GetUserId(User));

            var exp = _context.Experiences
                .FirstOrDefault(e => e.Id == id && e.CVId == cv.Id);

            if (exp == null) return NotFound();

            ViewBag.FormAction = Url.Action("Edit");
            return PartialView("Partials/_ExperienceForm", exp);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Experience model)
        {
            var cv = _context.CVs.First(c => c.UserId == _userManager.GetUserId(User));
            var existing = _context.Experiences.FirstOrDefault(e => e.Id == model.Id && e.CVId == cv.Id);

            if (existing == null) return NotFound();

            existing.Role = model.Role;
            existing.Company = model.Company;
            existing.StartYear = model.StartYear;
            existing.EndYear = model.EndYear;
            existing.Description = Request.Form["Description"];

            _context.SaveChanges();
            return RedirectToAction("Preview", "CV");
        }

        public IActionResult Delete(int id)
        {
            var cv = _context.CVs.First(c => c.UserId == _userManager.GetUserId(User));
            var exp = _context.Experiences.FirstOrDefault(e => e.Id == id && e.CVId == cv.Id);

            if (exp == null) return NotFound();

            _context.Experiences.Remove(exp);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }
    }
}
