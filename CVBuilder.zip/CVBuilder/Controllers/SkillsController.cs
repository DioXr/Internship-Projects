﻿using CVBuilder.Data;
using CVBuilder.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace CVBuilder.Controllers
{
    [Authorize]
    public class SkillsController : CvBaseController
    {
        public SkillsController(
            ApplicationDbContext context,
            UserManager<ApplicationUser> userManager
        ) : base(context, userManager)
        {
        }

        // CREATE (GET)
        public IActionResult Create()
        {
            return View();
        }

        // CREATE (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Skill model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            model.CVId = cv.Id;

            // Manual assignment (same as Education)
            model.SkillName = Request.Form["SkillName"];

            if (string.IsNullOrWhiteSpace(model.SkillName))
            {
                ModelState.AddModelError("SkillName", "Skill is required");
                return View(model);
            }

            _context.Skills.Add(model);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }


        // EDIT (GET)
        public IActionResult Edit(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var skill = _context.Skills
                .FirstOrDefault(s => s.Id == id && s.CVId == cv.Id);

            if (skill == null)
            {
                return NotFound();
            }

            return View(skill);
        }

        // EDIT (POST)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Skill model)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var existing = _context.Skills
                .FirstOrDefault(s => s.Id == model.Id && s.CVId == cv.Id);

            if (existing == null)
            {
                return NotFound();
            }

            existing.SkillName = Request.Form["SkillName"];

            if (string.IsNullOrWhiteSpace(existing.SkillName))
            {
                ModelState.AddModelError("SkillName", "Skill is required");
                return View(model);
            }

            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }

        // PARTIAL VIEWS
        [HttpGet]
        public IActionResult CreatePartial()
        {
            ViewBag.FormAction = Url.Action("Create");
            return PartialView("Partials/_SkillForm", new Skill());
        }

        [HttpGet]
        public IActionResult EditPartial(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var skill = _context.Skills
                .FirstOrDefault(s => s.Id == id && s.CVId == cv.Id);

            if (skill == null)
                return NotFound();

            ViewBag.FormAction = Url.Action("Edit");
            return PartialView("Partials/_SkillForm", skill);
        }


        // DELETE
        public IActionResult Delete(int id)
        {
            var userId = _userManager.GetUserId(User);
            var cv = _context.CVs.First(c => c.UserId == userId);

            var skill = _context.Skills
                .FirstOrDefault(s => s.Id == id && s.CVId == cv.Id);

            if (skill == null)
            {
                return NotFound();
            }

            _context.Skills.Remove(skill);
            _context.SaveChanges();

            return RedirectToAction("Preview", "CV");
        }
    }
}
