﻿using Microsoft.AspNetCore.Identity;
using CVBuilder.Models;

public static class DbInitializer
{
    public static async Task SeedAdminAsync(IServiceProvider services)
    {
        var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();


        if (!await roleManager.RoleExistsAsync("Admin"))
        {
            await roleManager.CreateAsync(new IdentityRole("Admin"));
        }

        if (!await roleManager.RoleExistsAsync("ContentManager"))
        {
            await roleManager.CreateAsync(new IdentityRole("ContentManager"));
        }


        var adminEmail = "admin@cvbuilder.com";
        var adminUser = await userManager.FindByEmailAsync(adminEmail);

        if (adminUser == null)
        {
            adminUser = new ApplicationUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                EmailConfirmed = true
            };

            await userManager.CreateAsync(adminUser, "Admin@123");
            await userManager.AddToRoleAsync(adminUser, "Admin");
        }



        var cmEmail = "contentmanager@cvbuilder.com";
        var contentManager = await userManager.FindByEmailAsync(cmEmail);

        if (contentManager == null)
        {
            contentManager = new ApplicationUser
            {
                UserName = cmEmail,
                Email = cmEmail,
                EmailConfirmed = true
            };

            await userManager.CreateAsync(contentManager, "Content@123");
            await userManager.AddToRoleAsync(contentManager, "ContentManager");
        }
    }
}
